
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.image import Image
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.audio import SoundLoader
from kivy.uix.label import Label
from kivy.vector import Vector
from random import randint

Window.size = (800, 600)

class Player(Image):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = (50, 50)
        self.source = "assets/player.png"
        self.pos = (Window.width / 2, Window.height / 2)
        self.speed = 10

    def move(self, direction):
        x, y = self.pos
        if direction == 'up' and y < Window.height - self.height:
            self.pos = (x, y + self.speed)
        elif direction == 'down' and y > 0:
            self.pos = (x, y - self.speed)
        elif direction == 'left' and x > 0:
            self.pos = (x - self.speed, y)
        elif direction == 'right' and x < Window.width - self.width:
            self.pos = (x + self.speed, y)

class Bullet(Image):
    def __init__(self, pos, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = (10, 10)
        self.source = "assets/bullet.png"
        self.pos = pos

    def move(self):
        x, y = self.pos
        self.pos = (x, y + 15)

class Enemy(Image):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = (40, 40)
        self.source = "assets/enemy.png"
        self.pos = (randint(0, Window.width - 40), Window.height)
        self.speed = 3

    def move(self):
        x, y = self.pos
        self.pos = (x, y - self.speed)

class GameWidget(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.score = 0
        self.player = Player()
        self.bullets = []
        self.enemies = []
        self.score_label = Label(text=f"Score: {self.score}", pos=(10, Window.height - 40), color=(1,1,1,1))
        self.shoot_sound = SoundLoader.load("assets/shoot.wav")
        self.add_widget(self.player)
        self.add_widget(self.score_label)
        Clock.schedule_interval(self.update, 1.0 / 60.0)
        Clock.schedule_interval(self.spawn_enemy, 1.5)
        self._keyboard = Window.request_keyboard(self._keyboard_closed, self)
        self._keyboard.bind(on_key_down=self.on_key_down)

    def _keyboard_closed(self):
        self._keyboard.unbind(on_key_down=self.on_key_down)
        self._keyboard = None

    def on_key_down(self, keyboard, keycode, text, modifiers):
        if keycode[1] == 'w': self.player.move('up')
        elif keycode[1] == 's': self.player.move('down')
        elif keycode[1] == 'a': self.player.move('left')
        elif keycode[1] == 'd': self.player.move('right')
        elif keycode[1] == 'spacebar':
            bullet = Bullet(pos=(self.player.center_x - 5, self.player.top))
            self.add_widget(bullet)
            self.bullets.append(bullet)
            if self.shoot_sound:
                self.shoot_sound.play()

    def spawn_enemy(self, dt):
        enemy = Enemy()
        self.add_widget(enemy)
        self.enemies.append(enemy)

    def update(self, dt):
        for bullet in self.bullets[:]:
            bullet.move()
            if bullet.y > Window.height:
                self.remove_widget(bullet)
                self.bullets.remove(bullet)

        for enemy in self.enemies[:]:
            enemy.move()
            if enemy.y < 0:
                self.remove_widget(enemy)
                self.enemies.remove(enemy)

        for bullet in self.bullets[:]:
            for enemy in self.enemies[:]:
                if bullet.collide_widget(enemy):
                    self.remove_widget(bullet)
                    self.remove_widget(enemy)
                    self.bullets.remove(bullet)
                    self.enemies.remove(enemy)
                    self.score += 1
                    self.score_label.text = f"Score: {self.score}"
                    break

class FreeFireApp(App):
    def build(self):
        return GameWidget()

if __name__ == "__main__":
    FreeFireApp().run()
